#bin/sh
kubectl delete -f ./
kubectl delete ns supermap

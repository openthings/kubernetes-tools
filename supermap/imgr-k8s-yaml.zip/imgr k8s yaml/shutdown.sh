#bin/sh
kubectl delete -f ./

#bin/sh
kubectl delete -f ./ -n supermap
